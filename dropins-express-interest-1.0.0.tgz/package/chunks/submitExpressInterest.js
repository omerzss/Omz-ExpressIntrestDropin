/*! Copyright 2026 Adobe
All Rights Reserved. */
const o="/api/v1/web/ExpressInterest/submit-public";async function i(s,e){const n=s.replace(/\/$/,"")+o,t=await fetch(n,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(e)});if(!t.ok){const r=await t.text();throw new Error(`Express Interest submission failed: ${t.status} ${t.statusText} - ${r}`)}return t}export{i as s};
//# sourceMappingURL=submitExpressInterest.js.map
