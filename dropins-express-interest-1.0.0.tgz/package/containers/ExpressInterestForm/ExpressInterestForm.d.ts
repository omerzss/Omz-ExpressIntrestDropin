import { FunctionComponent } from 'preact/hooks';

export interface ExpressInterestFormProps {
    baseUrl: string;
}
export declare const ExpressInterestForm: FunctionComponent<ExpressInterestFormProps>;
//# sourceMappingURL=ExpressInterestForm.d.ts.map