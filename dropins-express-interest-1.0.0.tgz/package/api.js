/*! Copyright 2026 Adobe
All Rights Reserved. */
import{s as G}from"./chunks/submitExpressInterest.js";import{Initializer as n}from"@dropins/tools/lib.js";import{FetchGraphQL as o}from"@dropins/tools/fetch-graphql.js";const e=new n({init:async t=>{const i={};e.config.setConfig({...i,...t})},listeners:()=>[]}),a=e.config,{setEndpoint:c,setFetchGraphQlHeader:f,removeFetchGraphQlHeader:h,setFetchGraphQlHeaders:p,fetchGraphQl:g,getConfig:l}=new o().getMethods();export{a as config,g as fetchGraphQl,l as getConfig,e as initialize,h as removeFetchGraphQlHeader,c as setEndpoint,f as setFetchGraphQlHeader,p as setFetchGraphQlHeaders,G as submitExpressInterest};
//# sourceMappingURL=api.js.map
